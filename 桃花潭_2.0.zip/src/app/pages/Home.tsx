import { motion } from 'motion/react';
import { Link } from 'react-router';
import { ArrowRight, ChevronDown } from 'lucide-react';
import heroImage from '../../imports/9.png';
import { IMAGES } from '../components/shared/images';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const SERIF = { fontFamily: '"Noto Serif SC", serif' } as const;

const PROBLEMS = [
  { title: '游客停留短', desc: '观光打卡多，深度体验少，人均停留时间不足半日。' },
  { title: '资源较分散', desc: '桃花潭、查济、宣纸、茶山等资源之间缺少主题化联动。' },
  { title: '村民参与弱', desc: '本地生活资源尚未充分转化为可参与、可传播的体验资源。' },
  { title: '淡旺季明显', desc: '乡村文旅节奏依赖旺季客流，需要全年可持续的运营节律。' },
];

const METHOD_STEPS = ['在地资源', '痛点诊断', '体验转译', '主题线路', '社群复购', '价值共生'];

const MATRIX = {
  seasons: ['春', '夏', '秋', '冬'],
  rows: [
    { label: '自然之美', items: ['茶山寻香', '桃潭水岸', '查济秋色', '民宿围炉'] },
    { label: '艺术之美', items: ['宣纸初体验', '诗词夜读', '村巷写生', '非遗雅集'] },
    { label: '运动之美', items: ['皖南轻徒步', '桃潭龙舟', '川藏线自驾', '康养慢行'] },
  ],
};

const RESOURCE_BLOCKS = [
  { title: '桃花潭', sub: '诗意水岸与龙舟民俗', desc: '李白诗中「桃花潭水深千尺」的千年诗意之地。AAAA景区，以官方实时信息为准。', img: IMAGES.lakeMountain, keys: ['诗仙足迹', '渡口日记', '桃潭龙舟'] },
  { title: '查济', sub: '古村生活与写生研学', desc: '中国现存较大的明清古村落群，白墙黛瓦间的徽州日常。', img: IMAGES.bridgeVillage, keys: ['查济一日村民', '村巷写生', '乡野共食'] },
  { title: '宣纸 / 茶山 / 村咖', sub: '非遗、产业与青年创业', desc: '从捞纸晒纸到茶山寻香，从村咖门头到民宿围炉——泾县的日常即体验。', img: IMAGES.tea, keys: ['我的第一张宣纸', '谷雨春茶', '村咖一日主理人'] },
];

const RESEARCH_CARDS = [
  { tag: '实践报告', title: '社会实践报告', desc: '泾县「小而美」文旅调研的一手记录与分析框架。' },
  { tag: '大创模型', title: '大创项目模型', desc: '价值共生视域下的乡村文旅精耕化模型原型。' },
  { tag: '专题视频', title: '青春华章·泾县调研纪实', desc: '茶山、古村、宣纸工坊、桃花潭水岸的青年视角。' },
  { tag: '策划建议', title: '农文旅融合策划建议', desc: '面向村民、运营方与地方合作方的可读性输出。' },
  { tag: '原型输出', title: '体验单元原型', desc: '10 个「源于在地、重在参与」的小而美体验单元卡片。' },
];

export function Home() {
  return (
    <div style={{ background: '#FAF5EA', color: '#2F4F3A' }}>
      {/* Hero */}
      <section className="relative min-h-[720px] w-full overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroImage})` }} />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(30,45,40,0.55) 0%, rgba(30,45,40,0.35) 40%, rgba(245,239,225,0.85) 100%)' }} />
        <div className="absolute inset-0 pointer-events-none opacity-40 mix-blend-overlay" style={{ backgroundImage: 'radial-gradient(circle at 30% 40%, rgba(255,255,255,0.15), transparent 50%)' }} />

        <div className="relative max-w-[1360px] mx-auto px-8 pt-40 pb-24">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="mb-6 flex items-center gap-3">
            <span className="inline-block w-8 h-[1px]" style={{ background: '#F5C6BE' }} />
            <span className="text-white/80" style={{ ...SERIF, fontSize: '13px', letterSpacing: '0.3em' }}>JINGXIAN · 小而美</span>
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.1 }} className="text-white mb-5 max-w-[840px]" style={{ ...SERIF, fontSize: 'clamp(2.6rem,5.5vw,4.5rem)', lineHeight: 1.15 }}>
            小而美，如何撬动大振兴
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.25 }} className="text-white/85 mb-8 max-w-[720px]" style={{ ...SERIF, fontSize: 'clamp(1rem,1.6vw,1.35rem)', letterSpacing: '0.05em' }}>
            价值共生视域下泾县农文旅融合的精耕化探索
          </motion.p>
          <motion.p initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="text-white/80 mb-10 max-w-[680px]" style={{ fontSize: '15px', lineHeight: 1.9 }}>
            从桃花潭的一汪诗意，到查济古村的一砖一瓦；从宣纸工坊的一捞一晒，到茶山村咖的一杯一盏。南开青年走进安徽泾县，尝试以场景美学重塑乡村文旅体验，让游客成为「半本地人」，让村民成为「生活合伙人」。
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.55 }} className="flex flex-wrap gap-4">
            <Link to="/project-intro" className="inline-flex items-center gap-2 rounded-full px-7 py-3 transition-all hover:-translate-y-0.5" style={{ background: '#2F4F3A', color: '#FAF5EA', fontSize: '14px' }}>
              查看项目模型 <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/routes" className="inline-flex items-center gap-2 rounded-full px-7 py-3 transition-all hover:-translate-y-0.5" style={{ background: 'rgba(255,255,255,0.12)', color: '#fff', border: '1px solid rgba(255,255,255,0.45)', backdropFilter: 'blur(6px)', fontSize: '14px' }}>
              浏览四季线路
            </Link>
            <Link to="/booking" className="inline-flex items-center gap-2 rounded-full px-7 py-3 transition-all hover:-translate-y-0.5" style={{ background: '#F5C6BE', color: '#2F4F3A', fontSize: '14px' }}>
              参与共创体验
            </Link>
          </motion.div>
        </div>
        <ChevronDown className="w-6 h-6 text-white/60 absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce" />
      </section>

      {/* 视频占位 */}
      <section className="px-8 -mt-16 relative z-10">
        <div className="max-w-[1360px] mx-auto rounded-2xl overflow-hidden border" style={{ borderColor: '#E8DFC9', background: '#F5EFE1' }}>
          <div className="aspect-[21/6] flex items-center justify-center relative" style={{ background: 'linear-gradient(135deg,#3D5D4B 0%,#7BA79D 50%,#F5C6BE 100%)' }}>
            <div className="text-center text-white/90 px-8">
              <p style={{ ...SERIF, fontSize: '13px', letterSpacing: '0.3em' }}>VIDEO PLACEHOLDER · 8-12s 静音循环</p>
              <p className="mt-2" style={{ fontSize: '13px' }}>茶山晨雾 → 古村巷道 → 宣纸捞纸 → 桃花潭水面 → 青年调研记录</p>
              <p className="mt-2" style={{ fontSize: '11px', opacity: 0.75 }}>素材来源：团队实地拍摄（占位）</p>
            </div>
          </div>
        </div>
      </section>

      {/* 核心问题 */}
      <section className="py-24 px-8">
        <div className="max-w-[1360px] mx-auto">
          <SectionHeader eyebrow="01 · 核心问题" title="资源富集，为什么还需要重新组织？" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-14">
            {PROBLEMS.map((p, i) => (
              <motion.div key={p.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="rounded-2xl p-8 border" style={{ background: '#FFFFFF', borderColor: '#E8DFC9' }}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center mb-5" style={{ background: '#F5EFE1', color: '#2F4F3A', fontFamily: 'serif' }}>{`0${i + 1}`}</div>
                <h3 className="mb-3" style={{ ...SERIF, fontSize: '18px', color: '#2F4F3A' }}>{p.title}</h3>
                <p style={{ fontSize: '13px', lineHeight: 1.8, color: '#3D5D4B' }}>{p.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 我们的方法 */}
      <section className="py-24 px-8" style={{ background: '#F5EFE1' }}>
        <div className="max-w-[1360px] mx-auto">
          <SectionHeader eyebrow="02 · 我们的方法" title="从资源到场景，从看风景到过一天本地生活" />
          <div className="mt-14 overflow-x-auto">
            <div className="flex items-center gap-2 min-w-max justify-center pb-4">
              {METHOD_STEPS.map((step, i) => (
                <div key={step} className="flex items-center gap-2">
                  <div className="px-6 py-4 rounded-xl border shadow-sm" style={{ background: '#FAF5EA', borderColor: '#7BA79D', color: '#2F4F3A', ...SERIF, fontSize: '15px', minWidth: '132px', textAlign: 'center' }}>
                    {step}
                  </div>
                  {i < METHOD_STEPS.length - 1 && <ArrowRight className="w-5 h-5" style={{ color: '#7BA79D' }} />}
                </div>
              ))}
            </div>
          </div>
          <p className="text-center mt-8 max-w-[720px] mx-auto" style={{ fontSize: '13px', color: '#8B6F47', lineHeight: 1.9 }}>
            我们不追求一次性的「打卡流量」，而是把泾县的自然节律、村民日常、文化脉络与产业场景，翻译成可以被游客亲手参与的小型体验。
          </p>
        </div>
      </section>

      {/* 3×4 矩阵 */}
      <section className="py-24 px-8">
        <div className="max-w-[1360px] mx-auto">
          <SectionHeader eyebrow="03 · 3×4 四季美学矩阵" title="以春夏秋冬为节奏，以自然/艺术/运动为维度" />
          <div className="mt-14 rounded-2xl p-6 lg:p-10 border overflow-x-auto" style={{ background: '#FFFFFF', borderColor: '#E8DFC9' }}>
            <div className="grid min-w-[720px]" style={{ gridTemplateColumns: '140px repeat(4,1fr)', gap: '12px' }}>
              <div />
              {MATRIX.seasons.map(s => (
                <div key={s} className="text-center py-3" style={{ ...SERIF, fontSize: '16px', color: '#2F4F3A', borderBottom: '1px solid #E8DFC9' }}>{s}</div>
              ))}
              {MATRIX.rows.map(row => (
                <div key={row.label} className="contents">
                  <div className="flex items-center justify-end pr-4" style={{ ...SERIF, fontSize: '14px', color: '#8B6F47' }}>{row.label}</div>
                  {row.items.map((cell, i) => (
                    <div key={i} className="rounded-xl p-5 border transition-all hover:-translate-y-1 hover:shadow-md cursor-default" style={{ background: i % 2 === 0 ? '#F5EFE1' : '#FAF5EA', borderColor: '#E8DFC9' }}>
                      <p style={{ ...SERIF, fontSize: '15px', color: '#2F4F3A' }}>{cell}</p>
                      <p className="mt-2" style={{ fontSize: '11px', color: '#8B6F47' }}>{MATRIX.seasons[i]} × {row.label}</p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          <div className="text-center mt-8">
            <Link to="/routes" className="inline-flex items-center gap-2" style={{ color: '#2F4F3A', fontSize: '14px' }}>
              查看完整四季线路 <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 三大资源板块 */}
      <section className="py-24 px-8" style={{ background: '#F5EFE1' }}>
        <div className="max-w-[1360px] mx-auto">
          <SectionHeader eyebrow="04 · 三大资源板块" title="桃花潭 · 查济 · 宣纸 / 茶山 / 村咖" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-14">
            {RESOURCE_BLOCKS.map((b, i) => (
              <motion.div key={b.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="rounded-2xl overflow-hidden border group" style={{ background: '#FAF5EA', borderColor: '#E8DFC9' }}>
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback src={b.img} alt={b.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg,transparent 50%,rgba(47,79,58,0.6) 100%)' }} />
                  <div className="absolute bottom-4 left-5 right-5 text-white">
                    <h3 style={{ ...SERIF, fontSize: '22px' }}>{b.title}</h3>
                    <p className="mt-1" style={{ fontSize: '12px', opacity: 0.9 }}>{b.sub}</p>
                  </div>
                </div>
                <div className="p-6">
                  <p style={{ fontSize: '13px', lineHeight: 1.8, color: '#3D5D4B' }}>{b.desc}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {b.keys.map(k => (
                      <span key={k} className="px-3 py-1 rounded-full" style={{ fontSize: '11px', background: '#F5EFE1', color: '#2F4F3A', border: '1px solid #E8DFC9' }}>{k}</span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          <p className="text-center mt-8" style={{ fontSize: '12px', color: '#8B6F47' }}>
            图片素材：优先使用团队实地拍摄；示意图片仅作占位，实际发布前将替换为授权素材。
          </p>
        </div>
      </section>

      {/* 生活合伙人机制 */}
      <section className="py-24 px-8">
        <div className="max-w-[1360px] mx-auto">
          <SectionHeader eyebrow="05 · 生活合伙人机制" title="从「一次性消费」到「长期价值共生」" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-14">
            {[
              { role: '游客', from: '一次性消费者', to: '半本地人', desc: '不再只看风景，而是过一天当地生活。参与采茶、捞纸、共食、围炉。' },
              { role: '村民', from: '被消费者', to: '生活合伙人', desc: '茶农、纸匠、民宿主、村咖主理人共同设计体验、共享收益、共讲故事。' },
              { role: '运营方', from: '服务商', to: '场景生态园丁', desc: '不只是卖产品，而是持续经营资源、社群与内容的生态。' },
            ].map((c, i) => (
              <div key={c.role} className="rounded-2xl p-8 border" style={{ background: i === 1 ? '#F5EFE1' : '#FAF5EA', borderColor: '#E8DFC9' }}>
                <p style={{ ...SERIF, fontSize: '13px', color: '#8B6F47', letterSpacing: '0.15em' }}>{`0${i + 1} · ${c.role}`}</p>
                <div className="flex items-center gap-3 my-5">
                  <span style={{ fontSize: '13px', color: '#8B6F47', textDecoration: 'line-through' }}>{c.from}</span>
                  <ArrowRight className="w-4 h-4" style={{ color: '#7BA79D' }} />
                  <span style={{ ...SERIF, fontSize: '17px', color: '#2F4F3A' }}>{c.to}</span>
                </div>
                <p style={{ fontSize: '13px', lineHeight: 1.85, color: '#3D5D4B' }}>{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 调研成果 */}
      <section className="py-24 px-8" style={{ background: '#2F4F3A', color: '#FAF5EA' }}>
        <div className="max-w-[1360px] mx-auto">
          <SectionHeader eyebrow="06 · 调研成果" title="来自泾县的一手记录与研究输出" light />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-14">
            {RESEARCH_CARDS.map((c, i) => (
              <motion.div key={c.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="rounded-2xl p-8" style={{ background: 'rgba(250,245,234,0.06)', border: '1px solid rgba(250,245,234,0.15)' }}>
                <p style={{ fontSize: '11px', color: '#F5C6BE', letterSpacing: '0.2em' }}>{c.tag}</p>
                <h3 className="mt-4 mb-3" style={{ ...SERIF, fontSize: '18px' }}>{c.title}</h3>
                <p style={{ fontSize: '13px', color: 'rgba(250,245,234,0.75)', lineHeight: 1.85 }}>{c.desc}</p>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link to="/research" className="inline-flex items-center gap-2 rounded-full px-7 py-3" style={{ background: '#F5C6BE', color: '#2F4F3A', fontSize: '14px' }}>
              进入调研成果 <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 共创报名入口 */}
      <section className="py-24 px-8">
        <div className="max-w-[1080px] mx-auto text-center rounded-3xl p-14 border" style={{ background: '#F5EFE1', borderColor: '#E8DFC9' }}>
          <p style={{ ...SERIF, fontSize: '13px', color: '#8B6F47', letterSpacing: '0.3em' }}>07 · 参与共创</p>
          <h2 className="mt-4 mb-5" style={{ ...SERIF, fontSize: 'clamp(1.75rem,3vw,2.5rem)', color: '#2F4F3A' }}>
            如果你也在意「小而美」的乡村文旅
          </h2>
          <p className="max-w-[680px] mx-auto mb-8" style={{ fontSize: '14px', color: '#3D5D4B', lineHeight: 1.9 }}>
            无论你是游客、村民、返乡青年、研学团队、民宿经营者或地方合作方，都可以参与「小而美」体验共创。我们将根据调研进度和合作条件与你联系——这里不做真实票务与支付，只做体验意向登记。
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/booking" className="inline-flex items-center gap-2 rounded-full px-7 py-3" style={{ background: '#2F4F3A', color: '#FAF5EA', fontSize: '14px' }}>
              提交共创意向 <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/experience-units" className="inline-flex items-center gap-2 rounded-full px-7 py-3" style={{ background: '#FFFFFF', color: '#2F4F3A', border: '1px solid #E8DFC9', fontSize: '14px' }}>
              浏览体验单元
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function SectionHeader({ eyebrow, title, light }: { eyebrow: string; title: string; light?: boolean }) {
  return (
    <div className="text-center max-w-[820px] mx-auto">
      <p style={{ ...SERIF, fontSize: '12px', letterSpacing: '0.3em', color: light ? '#F5C6BE' : '#8B6F47' }}>{eyebrow}</p>
      <h2 className="mt-3" style={{ ...SERIF, fontSize: 'clamp(1.6rem,2.8vw,2.25rem)', color: light ? '#FAF5EA' : '#2F4F3A', lineHeight: 1.35 }}>{title}</h2>
      <div className="mx-auto mt-6 h-[1px] w-16" style={{ background: light ? '#F5C6BE' : '#7BA79D' }} />
    </div>
  );
}
