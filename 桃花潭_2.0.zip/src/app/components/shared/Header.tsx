import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { Menu, X } from 'lucide-react';

const NAV_ITEMS = [
  { label: '首页', path: '/' },
  { label: '项目介绍', path: '/project-intro' },
  { label: '资源图谱', path: '/scenic' },
  { label: '体验单元', path: '/experience-units' },
  { label: '四季线路', path: '/routes' },
  { label: '生活合伙人', path: '/life-partners' },
  { label: '调研成果', path: '/research' },
  { label: '共创报名', path: '/booking' },
];

export function Header({ transparent = false }: { transparent?: boolean }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const isTransparent = transparent && !scrolled;
  const base = isTransparent
    ? 'fixed top-0 left-0 right-0 z-50 border-b border-white/10 backdrop-blur-md bg-white/10'
    : 'sticky top-0 z-50 border-b border-[#E8DFC9] backdrop-blur-xl bg-[#FAF5EA]/95';
  const textColor = isTransparent ? 'text-white/85 hover:text-white' : 'text-[#3D5D4B] hover:text-[#2F4F3A]';
  const activeColor = isTransparent ? 'text-white' : 'text-[#2F4F3A]';
  const logoText = isTransparent ? 'text-white' : 'text-[#2F4F3A]';
  const subText = isTransparent ? 'text-white/65' : 'text-[#8B6F47]';
  const iconColor = isTransparent ? 'text-white/80 hover:text-white' : 'text-[#3D5D4B]';

  return (
    <header className={base}>
      <div className="max-w-[1360px] mx-auto px-8 h-20 flex items-center justify-between gap-6">
        <Link to="/" className="flex items-center gap-3 shrink-0">
          <div className="w-11 h-11 rounded-xl flex items-center justify-center border" style={{ background: 'linear-gradient(135deg,#7BA79D 0%,#2F4F3A 100%)', color: '#FAF5EA', borderColor: 'rgba(255,255,255,0.25)', fontFamily: '"Noto Serif SC", serif' }}>泾</div>
          <div className="leading-tight">
            <h1 className={`${logoText}`} style={{ fontFamily: '"Noto Serif SC", serif', fontSize: '1.05rem', letterSpacing: '0.02em' }}>泾县「小而美」文旅共创平台</h1>
            <p className={`${subText}`} style={{ fontSize: '11px' }}>南开大学商学院赴安徽泾县实践队 · 大创项目原型</p>
          </div>
        </Link>
        <nav className="hidden xl:flex items-center gap-6">
          {NAV_ITEMS.map(item => {
            const active = item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`${active ? activeColor : textColor} transition-colors relative py-1`}
                style={{ fontSize: '14px' }}
              >
                {item.label}
                {active && <span className="absolute -bottom-1 left-0 right-0 h-[2px]" style={{ background: isTransparent ? '#F5C6BE' : '#7BA79D' }} />}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-3 shrink-0">
          <Link to="/booking" className="hidden sm:inline-flex items-center gap-2 rounded-full px-5 py-2 transition-all" style={{ background: isTransparent ? 'rgba(255,255,255,0.15)' : '#2F4F3A', color: isTransparent ? '#fff' : '#FAF5EA', border: isTransparent ? '1px solid rgba(255,255,255,0.35)' : 'none', fontSize: '13px' }}>
            参与共创
          </Link>
          <button className={`xl:hidden ${iconColor} p-2`} onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>
      {mobileOpen && (
        <div className="xl:hidden border-t bg-[#FAF5EA]" style={{ borderColor: '#E8DFC9' }}>
          <nav className="flex flex-col p-4 gap-1">
            {NAV_ITEMS.map(item => (
              <Link key={item.path} to={item.path} onClick={() => setMobileOpen(false)} className="px-4 py-3 rounded-lg text-[#3D5D4B] hover:bg-[#F5EFE1]" style={{ fontSize: '14px' }}>
                {item.label}
              </Link>
            ))}
            <p className="px-4 py-3 text-[#8B6F47]" style={{ fontSize: '11px' }}>项目原型展示，非官方售票平台</p>
          </nav>
        </div>
      )}
    </header>
  );
}
