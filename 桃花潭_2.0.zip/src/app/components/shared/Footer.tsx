import { Link } from 'react-router';

export function Footer() {
  return (
    <footer className="pt-16 pb-8 px-8 relative" style={{ background: '#F5EFE1', color: '#2F4F3A' }}>
      <div className="absolute inset-0 pointer-events-none opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, rgba(139,111,71,0.08) 0, transparent 40%), radial-gradient(circle at 80% 70%, rgba(123,167,157,0.1) 0, transparent 45%)' }} />
      <div className="max-w-[1360px] mx-auto relative">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-10">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#7BA79D 0%,#2F4F3A 100%)', color: '#FAF5EA', fontFamily: '"Noto Serif SC", serif' }}>泾</div>
              <div className="leading-tight">
                <h3 style={{ fontFamily: '"Noto Serif SC", serif', fontSize: '1rem' }}>泾县「小而美」文旅共创平台</h3>
                <p style={{ fontSize: '11px', color: '#8B6F47' }}>Jingxian Small-and-Beautiful Cultural-Tourism Co-creation Prototype</p>
              </div>
            </div>
            <p style={{ fontSize: '13px', color: '#3D5D4B', lineHeight: 1.7 }}>
              南开大学商学院赴安徽泾县实践队 / 大学生创新训练项目的数字化成果展示原型。以场景美学、价值共生方法论，探索乡村文旅从「流量狩猎」转向「留量耕耘」的路径。
            </p>
          </div>
          <div>
            <h4 className="mb-4" style={{ fontFamily: '"Noto Serif SC", serif', fontSize: '14px', color: '#2F4F3A' }}>项目模块</h4>
            <ul className="space-y-2" style={{ fontSize: '13px', color: '#3D5D4B' }}>
              <li><Link to="/project-intro" className="hover:text-[#6B2C91] transition-colors">项目介绍</Link></li>
              <li><Link to="/scenic" className="hover:text-[#6B2C91] transition-colors">资源图谱</Link></li>
              <li><Link to="/experience-units" className="hover:text-[#6B2C91] transition-colors">体验单元</Link></li>
              <li><Link to="/routes" className="hover:text-[#6B2C91] transition-colors">四季线路</Link></li>
              <li><Link to="/life-partners" className="hover:text-[#6B2C91] transition-colors">生活合伙人</Link></li>
              <li><Link to="/research" className="hover:text-[#6B2C91] transition-colors">调研成果</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-4" style={{ fontFamily: '"Noto Serif SC", serif', fontSize: '14px', color: '#2F4F3A' }}>资料说明</h4>
            <ul className="space-y-2" style={{ fontSize: '13px', color: '#3D5D4B' }}>
              <li><Link to="/support/about" className="hover:text-[#6B2C91] transition-colors">数据来源</Link></li>
              <li><Link to="/support/about" className="hover:text-[#6B2C91] transition-colors">图片来源</Link></li>
              <li><Link to="/support/about" className="hover:text-[#6B2C91] transition-colors">项目声明</Link></li>
              <li><Link to="/support/contact" className="hover:text-[#6B2C91] transition-colors">合作咨询</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-4" style={{ fontFamily: '"Noto Serif SC", serif', fontSize: '14px', color: '#2F4F3A' }}>项目声明</h4>
            <p style={{ fontSize: '12px', color: '#8B6F47', lineHeight: 1.75 }}>
              本平台为高校社会实践与大学生创新训练项目的前端原型展示，<strong style={{ color: '#3D5D4B' }}>不代表景区官方售票平台</strong>。景区等级、票价、开放时间等信息请以官方实时发布为准。
            </p>
          </div>
        </div>
        <div className="pt-6 flex flex-col md:flex-row justify-between items-center gap-3" style={{ borderTop: '1px solid #E8DFC9', fontSize: '11px', color: '#8B6F47' }}>
          <p>© 2026 泾县「小而美」文旅共创平台 · 南开大学商学院赴安徽泾县实践队</p>
          <p>项目原型展示 · 非官方售票平台</p>
        </div>
      </div>
    </footer>
  );
}
